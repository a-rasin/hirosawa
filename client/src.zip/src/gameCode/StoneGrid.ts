import Row from "./Row";

export default class StoneMap {
  rows: Row[];
  selectedStones: string[] = [];
  element: HTMLElement;
  gridSize: number = 0;
  gridWidth: number = 0;
  gridHeight: number = 0;
  colSequence: string = "";
  rowSequence: string = "";

  constructor(gridWidth: number, gridHeight: number) {
    this.gridSize = gridWidth * gridHeight;
    this.gridWidth = gridWidth;
    this.gridWidth = gridHeight;

    // Create a string sequence to compare against stone positions.
    // This will allow code to check if there is a winner (5 in a column)
    for (let i = 0; i < gridWidth; i++) {
      this.colSequence += i + 10;
    }

    // Same for rows
    for (let i = 0; i < gridHeight; i++) {
      this.rowSequence += i + 10;
    }

    this.rows = Array.from({ length: gridHeight }).map((_, index) => {
      return new Row(index, gridWidth);
    });

    this.element = document.createElement("div");
    this.element.classList.add("stone-map");
    this.element.append(...this.rows.map((row) => row.element));
    this.element.addEventListener("click", (event) => {
      this.checkForWinner();
    });
  }

  checkForWinner() {
    let winner = this.checkRowsForWinner();
    if (winner !== "") {
      alert(winner);
      globalThis.endGame = true;
      const gameStatus = document.getElementById("gameStatus");
      gameStatus!.innerHTML = "GAME ENDED: " + winner;
    }

    winner = this.checkColsForWinner();
    console.log("colWinner: " + winner);
    if (winner !== "") {
      alert(winner);
      globalThis.endGame = true;
      const gameStatus = document.getElementById("gameStatus");
      gameStatus!.innerHTML = "GAME ENDED: " + winner;
    }
  }

  checkColsForWinner() {
    let colArrayWhite: string[] = [];
    let colArrayBlack: string[] = [];
    let colSequence = this.colSequence;
    let gridWidth = this.gridWidth;
    let currentStone = "";
    let winner = "";

    for (let i = 10; i < gridWidth + 10; i++) {
      colArrayWhite = [];
      colArrayBlack = [];

      // check each row (by column index for stones to add to array)
      //this.rows.forEach(function (value) {
      for (let i = 0; i < this.rows.length; i++) {
        // white stones
        currentStone = this.rows[i].columnWhiteStones(i);
        if (currentStone !== "") colArrayWhite.push(currentStone);

        // black stones
        currentStone = this.rows[i].columnBlackStones(i);
        if (currentStone !== "") colArrayBlack.push(currentStone);
      }
      // if the array length is exactly 5 (not greater than 5) and the sequence matches the column sequence
      // then we have a winner (WHITE)
      if (colArrayWhite.length === 5) {
        if (colSequence.indexOf(colArrayWhite.join("")) >= 0)
          winner = "WHITE WON!";
      }
      // if the array length is exactly 5 (not greater than 5) and the sequence matches the column sequence
      // then we have a winner (BLACK)
      if (colArrayBlack.length === 5) {
        if (colSequence.indexOf(colArrayBlack.join("")) >= 0)
          winner = "BLACK WON!";
      }
    }
    return winner;
  }

  // compare the sequence of stones in a row against a preset sequence of 2-digit numbers to see if there are 5 in a row.
  checkRowsForWinner() {
    const colSequence = this.colSequence;
    let stoneCount = 0;
    let winner = "";
    this.rows.forEach(function (value) {
      const whiteStones = value.whiteStoneIds;
      stoneCount += whiteStones.length;
      // check that the number of white stones is exactly 5 (2 digits per stone so divide array length by 2)
      if (whiteStones.length == 10) {
        if (colSequence.indexOf(whiteStones) >= 0) winner = "WHITE WON!";
      }

      const blackStones = value.blackStoneIds;
      stoneCount += blackStones.length;
      // check that the number of black stones is exactly 5 (2 digits per stone so divide array length by 2)
      if (blackStones.length == 10) {
        if (colSequence.indexOf(blackStones) >= 0) winner = "BLACK WON!";
      }
    });
    stoneCount = stoneCount / 2;

    // if there is no winner and all of the available locations have been taken, the game is a draw
    if (winner === "" && stoneCount === this.gridSize)
      winner = "GAME IS A DRAW";

    return winner;
  }
}
