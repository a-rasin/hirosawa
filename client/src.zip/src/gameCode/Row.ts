import Stone from "./Stone";

export default class Row {
  id: number;
  rowStones: Stone[];
  element: HTMLDivElement;

  constructor(rowId: number, rowWidth: number) {
    this.id = rowId;
    this.rowStones = Array.from({ length: rowWidth }).map((_, index) => {
      return new Stone(index, rowId);
    });

    this.element = document.createElement("div");
    this.element.classList.add("row");
    this.element.append(...this.rowStones.map((stone) => stone.element));
  }

  // Get the number of selected white stones in a column
  columnWhiteStones(colId: number) {
    return this.rowStones
      .filter((stone) => stone.colId == colId && stone.isWhite)
      .map((stone) => stone.rowId)
      .toString();
  }

  // Get the number of selected black stones in a column
  columnBlackStones(colId: number) {
    return this.rowStones
      .filter((stone) => stone.colId == colId && stone.isBlack)
      .map((stone) => stone.rowId)
      .toString();
  }

  // Get the number of selected white stones in a row
  get whiteStoneIds() {
    return this.rowStones
      .filter((stone) => stone.isWhite)
      .map((stone) => stone.colId)
      .join("");
  }

  // Get the number of selected black stones in a row
  get blackStoneIds() {
    return this.rowStones
      .filter((stone) => stone.isBlack)
      .map((stone) => stone.colId)
      .join("");
  }
}
