import StoneGrid from "./StoneGrid";

declare global {
  var turn: string;
  var endGame: boolean;
}

// Black starts first
globalThis.turn = "BLACK";

export default class GoBoard {
  stoneGrid: StoneGrid | null = null;
  boardContainer: HTMLDivElement;
  boardGrid?: HTMLDivElement;
  boardOptions: HTMLDivElement;
  boardSizeSelector: HTMLSelectElement;
  boardResetButton: HTMLButtonElement;
  gameStatus: HTMLDivElement;
  currentTurn: string;

  constructor() {
    // Selector for game size
    this.boardSizeSelector = document.createElement("select");
    this.boardSizeSelector.id = "boardSizeSelector";
    this.boardSizeSelector.onchange = () => this.resetBoard();
    this.boardSizeSelector.appendChild(new Option("5 x 5", "5,5"));
    this.boardSizeSelector.appendChild(new Option("10 x 10", "10,10"));
    this.boardSizeSelector.appendChild(new Option("15 x 15", "15,15"));

    // Reset board button
    this.boardResetButton = document.createElement("button");
    this.boardResetButton.innerHTML = "Reset Board";
    this.boardResetButton.onclick = () => this.resetBoard();

    // Game status indicator
    this.gameStatus = document.createElement("div");
    this.gameStatus.id = "gameStatus";

    // Add options to the page
    this.boardOptions = document.createElement("div");
    this.boardOptions.id = "boardOptions";
    this.boardOptions.append(
      this.boardResetButton,
      this.boardSizeSelector,
      this.gameStatus
    );

    // Add the board
    this.boardContainer = document.createElement("div");
    this.boardContainer.id = "board";
    this.currentTurn = "BLACK";

    document
      .getElementById("main")
      ?.append(this.boardOptions, this.boardContainer);
  }

  // Add the stone grid
  setBoard() {
    // Get the desired size of board from the selector
    let arr = this.boardSizeSelector.value.split(",").map(Number);
    let gridWidth: number = arr[0];
    let gridHeight: number = arr[1];

    this.stoneGrid = new StoneGrid(gridWidth, gridHeight);
    this.boardContainer.append(this.stoneGrid.element);
    this.gameStatus.innerHTML = "ACTIVE PLAYER: BLACK";
  }

  // Function to reset the board to start a new game
  resetBoard() {
    var child = this.boardContainer.lastElementChild;
    while (child) {
      this.boardContainer.removeChild(child);
      child = this.boardContainer.lastElementChild;
    }

    // reset global game status
    globalThis.endGame = false;

    // create the board
    this.setBoard();
  }
}
