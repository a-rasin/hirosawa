//import { useNavigate, useParams } from "react-router";
//import { useParams } from "react-router";
//import games from "../data/games.json";
//import sessions from "../data/sessions.json";

//import style from "./Movie.module.css";
import GoBoard from "../components/GoBoard";

export default function Game({ size }: {size: number}) {
  return (
    <div>
      <h1>New Game:</h1>
      <GoBoard size={size} />
    </div>
  );
}
