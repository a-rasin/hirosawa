import { useContext } from 'react';
import { UserContext } from '../context';
import { Navigate, useParams } from "react-router";
import style from "./Movie.module.css";
import GoGrid from '../components/GoGrid';

export default function GameLog() {
  const { user } = useContext(UserContext);

  const games = JSON.parse(localStorage.getItem('history') ?? '[]');
  const { gameId } = useParams();
  if (!gameId) return null;
  const game = games[parseInt(gameId) - 1];
  if (!game) return null;
  if (!user) return <Navigate to="/login" />;

  return (
    <div className={style.container}>
      <h1 className={style.title}>Winner: {game.winner}</h1>
      <h5>Date: {game.date}</h5>
      <br />
      <GoGrid board={game.board} shouldShowNumbers={true} />
    </div>
  );
}
