import { GameItem } from "../components";
import style from "./Home.module.css";

export default function History() {
  const games = JSON.parse(localStorage.getItem('history') ?? '[]');
  return (
    <>
      <h1>Games History</h1>
      <div className={style.container}>
        {games.map(({ gameId, date, winner }: { gameId: number, date: string, winner: string }) => (
          <GameItem key={gameId} gameId={gameId} date={date} winner={winner} />
        ))}
      </div>
    </>
  );
}
