export { default as GameLog } from "./GameLog";
export { default as History } from "./History";
export { default as Game } from "./Game";
export { default as Home } from "./Home";
export { default as Login } from "./Login";
export { default as SignUp } from "./SignUp";
