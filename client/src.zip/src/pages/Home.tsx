//import { useEffect, useState } from "react";
import React, { useState, useEffect } from "react";
//import { Navigate, useNavigate } from "react-router-dom";
import { useNavigate } from "react-router-dom";

//import { MovieItem } from "../components";
//import type { Movie } from "../types";
//import http from "../utils/http";
import boards from "../data/boards.json";

import style from "./Home.module.css";

export default function Home({ boardSize, setBoardSize }: { boardSize: number, setBoardSize: React.Dispatch<React.SetStateAction<number>> }) {
  const navigate = useNavigate();

  useEffect(() => {
    setBoardSize(boards[0].size);
  }, []);

  const handleStart = () => {
    if (boardSize) {
      navigate("/game");
    } else {
      alert("Set Board Size");
    }
  };

  return (
    <>
      <select
        className={style.container}
        onChange={(e) => setBoardSize(parseInt(e.target.value))}
      >
        {boards.map(({ id, size }) => (
          <option key={id} value={size}>
            {size}
          </option>
        ))}
      </select>
      <button onClick={() => handleStart()}>Start</button>
    </>
  );
}
