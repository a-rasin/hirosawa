export interface Stone {
  stone: number;
  move: number;
};

export type Game = {
  gameId: number;
  winner: string;
  date: string;
  board: Stone[][];
};
