export type User = {
    username: string
  }