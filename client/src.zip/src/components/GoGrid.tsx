import '../gameCode/style.css';
import { Stone } from '../types/Game';

interface GoGridProps {
  board: Stone[][];
  handleClick?: (i: number, j: number) => void;
  shouldShowNumbers: boolean;
}

const GoGrid = ({ board, handleClick, shouldShowNumbers }: GoGridProps) => {
  const myHandleClick = handleClick ?? (() => null);
  return (
    <div id="board">
      {
        board.map((a, i) => (
          <div className="row">
            {
              a.map((b, j: number) => (
                <div onClick={() => myHandleClick(i, j) } className={`stone ${[shouldShowNumbers ? '' : 'available', 'white', 'black'][b.stone]}`}>
                  {shouldShowNumbers && b.move > 0 ? b.move : ''}
                </div>
              ))
            }
          </div>
        ))
      }
    </div>
  )
}

export default GoGrid;
